package com.cts.training.storedetails.scheduler.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
@Data
@AllArgsConstructor
@NoArgsConstructor

public class SchedulerReciever {
	
	@Value("${StatusSchedule.url}")
	 private String url;
	
	@Autowired
	RestTemplate restTemplate;
	
	@Scheduled(cron = "*/10 * * * * *")
	public void somejob()
	{
		String str=this.restTemplate.getForObject(url,String.class);
	
		log.info(str);
	}

	

}
