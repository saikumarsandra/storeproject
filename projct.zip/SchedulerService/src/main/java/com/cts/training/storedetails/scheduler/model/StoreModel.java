package com.cts.training.storedetails.scheduler.model;



import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class StoreModel {
	
	private Integer storeId;

	private String ownerId;

	private String storeName;

	private String phoneNumber;

	private String location;

	private String storeType;
	
	private String ownerName;
	
	private String status;

}
