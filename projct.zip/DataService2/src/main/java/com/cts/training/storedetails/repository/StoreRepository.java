package com.cts.training.storedetails.repository;



import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cts.training.storedetails.entity.Store;

@Repository
public interface StoreRepository extends JpaRepository<Store, Integer> {

	
	@Query("FROM Store str where str.ownerId=?1")
	List<Store> findByownerId(Integer ownerId);
	
	@Query("FROM Store str WHERE str.status='requested'")
	public List<Store> findStatusRequest();

	
}
