package com.cts.training.storedetails.repository;

import java.util.List;

import javax.validation.Valid;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cts.training.storedetails.entity.User;
import com.cts.training.storedetails.model.UserModel;

@Repository
public interface UserRepository extends JpaRepository<User, Integer> {

	List<User> findByuserName(String username);
	
	
	
	
}
