package com.cts.training.storedetails.service;

import java.util.List;
import java.util.Map;

import org.springframework.http.ResponseEntity;

import com.cts.training.storedetails.entity.Store;

public interface StoreServiceInterface {
	 public List<Store> getall();
	 public List<Store> findByownerId(Integer ownerId);
	 public Map<String, Boolean> deleteStore(Integer storeId);
	 public ResponseEntity<Store> updateStore(Integer storeId, Store storeDetails);
}
