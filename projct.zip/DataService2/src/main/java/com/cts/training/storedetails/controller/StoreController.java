package com.cts.training.storedetails.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;


import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cts.training.storedetails.entity.Store;

import com.cts.training.storedetails.model.StoreListModel;
import com.cts.training.storedetails.repository.StoreRepository;
import com.cts.training.storedetails.service.StoreService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
public class StoreController {
		
	@Autowired
	public StoreService storeService;
	@Autowired
	public StoreRepository storeRepository;

	
	@GetMapping("/allstores")
	public ResponseEntity<StoreListModel> getall(){	
	StoreListModel data = new StoreListModel();
		data.setStores(this. storeService.getall());
		ResponseEntity<StoreListModel> result = new ResponseEntity<StoreListModel>(data, HttpStatus.OK);
		log.info("recieved the list of store" +result);
		return result;
		
	}
	
	@GetMapping("/getStoreById/{ownerId}")
	public List<Store> getByOwnerId(@PathVariable Integer ownerId)
	{
	
	return  this.storeService.findByownerId(ownerId);
}
	@GetMapping("/store/status")
	public String editStatus()
	{
		 this.storeService.StatusReciever();
			return "Processed";
	}
	
	@PutMapping("/updateStore/{storeId}")
    public ResponseEntity<Store> updateStore(@PathVariable(value = "storeId") Integer storeId,
         @Valid @RequestBody Store storeDetails)  {
       Store data = storeRepository.getOne(storeId);
       data.setLocation(storeDetails.getLocation());
       data.setOwnerName(storeDetails.getOwnerName());
       data.setPhoneNumber(storeDetails.getPhoneNumber());
       data.setStoreName(storeDetails.getStoreName());
       data.setStoreType(storeDetails.getStoreType());
        final Store updatedStoreData = storeRepository.save(data);
        return ResponseEntity.ok(updatedStoreData);
    }	
	
	 @DeleteMapping("/delete/{storeId}")
	    public Map<String, Boolean> deleteStore(@PathVariable(value = "storeId") Integer storeId){
	         
	        Store  data = storeRepository.getOne(storeId);
	             storeRepository.delete(data);
	        Map<String, Boolean> response = new HashMap<>();
	        response.put("processed", Boolean.TRUE);
	        return response;
	    }
	
	
}
