package com.cts.training.storedetails.model;



import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor

public class RetailerModel {
	
	private Integer ownerId;
	
	private String ownerName;
	
	private String ownerNumber;
		
	private String loginPassword;
	

	
	private Boolean enabled;


}
