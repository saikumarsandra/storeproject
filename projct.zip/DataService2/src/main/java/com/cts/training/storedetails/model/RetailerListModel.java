package com.cts.training.storedetails.model;

import java.util.List;

import com.cts.training.storedetails.entity.Retailer;

import lombok.Getter;
import lombok.Setter;
@Getter
@Setter
public class RetailerListModel {

	
	public List<Retailer> retailer; 
}
