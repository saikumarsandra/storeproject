package com.cts.training.storedetails.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import com.cts.training.storedetails.entity.Retailer;
import com.cts.training.storedetails.entity.Store;
import com.cts.training.storedetails.model.StoreModel;
import com.cts.training.storedetails.repository.StoreRepository;

@Service
public class StoreService  implements StoreServiceInterface{
	
	@Autowired
	public StoreRepository storeRepo;
	
	
     public List<Store> getall() {
		
		return  storeRepo.findAll();
	}
	
     public List<Store> findByownerId(Integer ownerId){
    	 
    	
    	 return storeRepo.findByownerId(ownerId);
 		}
     
     public void StatusReciever()
 	{
 		List<Store> getstatus=this.storeRepo.findStatusRequest();
 		for(Store str:getstatus)
 		{
 				Store store=new Store(str.getStoreId(),str.getOwnerId(),str.getStoreName(),str.getPhoneNumber(),str.getLocation(),str.getStoreType(),str.getOwnerName(),"processed");
 				this.storeRepo.save(store);
 		}
 	}
     public ResponseEntity<Store> updateStore(@PathVariable(value = "storeId") Integer storeId,
             @Valid @RequestBody Store storeDetails)  {
          Store data = storeRepo.getOne(storeId);
          data.setLocation(storeDetails.getLocation());
          data.setOwnerName(storeDetails.getOwnerName());
          data.setPhoneNumber(storeDetails.getPhoneNumber());
          data.setStoreName(storeDetails.getStoreName());
          data.setStoreType(storeDetails.getStoreType());
        final Store updatedStoreData = storeRepo.save(data);
            return ResponseEntity.ok(updatedStoreData);
        }	
     
     public Map<String, Boolean> deleteStore(@PathVariable(value = "storeId") Integer storeId){
         
	        Store  data = storeRepo.getOne(storeId);
	             storeRepo.delete(data);
	        Map<String, Boolean> response = new HashMap<>();
	        response.put("processed", Boolean.TRUE);
	        return response;
	    }
}
