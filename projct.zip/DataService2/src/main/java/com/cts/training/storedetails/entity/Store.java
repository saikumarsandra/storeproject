package com.cts.training.storedetails.entity;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;

import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Table(name="storedetails")

public class Store implements Serializable{

	private static final long serialVersionUID  = 1L;  
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer storeId;
	
	@Column
	private Integer ownerId;

	@Column
	private String storeName;

	@Column
	private String phoneNumber;
	
	@Column
	private String location;
	@Column
	private String storeType;
	
	@Column
	private String ownerName;
	
	@Column(length = 100)
	private String status;


	
	/*@ManyToOne
	@JoinColumn(name="ownerId")
	private  Retailer ownerId;*/


}
