package com.cts.training.storedetails.model;

import java.util.List;

import com.cts.training.storedetails.entity.User;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UserListModel {
	public List<User> users; 
}
