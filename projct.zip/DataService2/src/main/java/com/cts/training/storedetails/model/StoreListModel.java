package com.cts.training.storedetails.model;

import java.util.List;

import com.cts.training.storedetails.entity.Store;

import lombok.Getter;
import lombok.Setter;
@Getter
@Setter
public class StoreListModel {

	public List<Store> stores; 
}
