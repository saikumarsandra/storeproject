package com.cts.training.storedetails.sftp.controller;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.integration.annotation.Default;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cts.training.storedetails.sftp.model.StoreDetails;
import com.cts.training.storedetails.sftp.repository.StoreRepository;
import com.cts.training.storedetails.sftp.service.StoreDetailsService;
import com.fasterxml.jackson.databind.MappingIterator;
import com.fasterxml.jackson.dataformat.csv.CsvMapper;
import com.fasterxml.jackson.dataformat.csv.CsvParser;
import com.fasterxml.jackson.dataformat.csv.CsvSchema;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
public class StoreDataController {
	@Autowired
	public StoreDetailsService storeService;
	@Autowired
	public StoreRepository repo;
	
	

	@GetMapping("/allstores")
	public List<StoreDetails> getall() throws IOException{	
	  
	File	file = new File("tmp\\store.csv");
		  
		 CsvMapper mapper = new CsvMapper();
	
         CsvSchema schema = mapper.schemaFor(StoreDetails.class).withHeader();
      		                   
         MappingIterator<StoreDetails> storedetails = mapper.readerFor(StoreDetails.class)
      		                                              .with(schema)
      		                                              .readValues(file);
           List<StoreDetails> storelist = storedetails.readAll();
        //   this.repo.saveAll(storelist);
		log.info("==========>"+storelist);
		
		log.info("==========>"+file);
		log.info("==========>"+storedetails);
		return storelist;
	}	
	
	@GetMapping("/getStoreById/{ownerId}")
	public List<StoreDetails> getByOwnerId(@PathVariable Integer ownerId)
	{
	
	return  this.storeService.findByownerId(ownerId);
}
}


