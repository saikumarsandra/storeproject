package com.cts.training.storedetails.sftp.controller;

public class RestClientController {

}
