package com.cts.training.storedetails.sftp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SftpServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
